// ============================================================
//  ملف التحكم الوحيد لموقع دكتور سبورت — جاهز ومكتمل
// ============================================================
window.CONFIG = {
  SITE_NAME: "دكتور سبورت",
  SHEET_API_URL: "https://script.google.com/macros/s/AKfycbwpLaQki_ld3c4KgwUgumsHQtSvVhknwVF3zHywu5LoSz68-PvRy7Mlaa8b5AHeDjVXdg/exec",


  // المنطقة الزمنية لأوقات الجدول إذا كُتبت بدون منطقة (مثل 2026-11-15 20:00). اليمن/السعودية = +03:00
  SHEET_TZ: "+03:00",
  // مدة المباراة بالدقائق (لحساب "جارية/انتهت" تلقائياً لمباريات الجدول إن لم يوجد عمود status)
  MATCH_MINUTES: 130,

  // شعار الموقع
  LOGO: "logo.png",

  // حسابات التواصل الاجتماعي
  SOCIAL: {
    whatsapp:  "https://wa.me/967775393823",
    telegram:  "https://t.me/CHANGE_ME",
    instagram: "https://instagram.com/CHANGE_ME",
    facebook:  "https://facebook.com/CHANGE_ME"
  },

  // الصورة الكبرى (Hero Banner) بمقاس 16:9 ومتجاوبة
  HERO: {
    enabled: true,
    image: "2.jpg",
    title: "المباراة الكبرى",
    subtitle: "تابع أثارة كرة القدم مباشرة وبأعلى جودة",
    matchId: "",
    kickoff: "2026-12-31T18:00:00Z",
    link: "https://tv1.dzmatch.site/p/5bei5.html",
    buttonText: "شاهد الآن"
  },

  // روابط البث الخاصة بالمباريات
  STREAMS: {
   "560636": "https://st.sp5.fun/2026/08/blog-post_19.html",
  },

  // الرابط الافتراضي للمشغل
  DEFAULT_STREAM: "https://badboy.shootsimo.com/splayer/Live1.php",
  DEFAULT_NOTE: "نعتذر، رابط بث هذه المباراة غير متوفر حالياً. نعرض لك المشغل العام.",

  PLAYER_TEMPLATE: "{URL}",

     ADS: {
    top:         { html: "", height: 90  },   
    list:        { html: "", height: 250 },
    // ضع الكود هنا داخل علامتي التنزيل ``
    belowPlayer: { html: "", height: 300 },   
    bottom:      { html: "", height: 90  }    
  },
  REFRESH_SECONDS: 90
};
